# Task TSK-V6J8MSSD: acceptance declared before implementation

Source: https://taskmarket.dev/tasks/0x1fb989a3256eadc92fe09e863ca36bed7765e5bcb2f8d2c28183201e467c272d

- Two to four seats, with humans and bots in the same authoritative match.
- Browser UI without a login, installation, wallet, or payment.
- HTTP/JSON create, join, read, start, and move operations; documented sample bot.
- Shareable lobby code, optional bot fill, score, explicit final outcome and replay.
- Bounded turns: at most 480 seconds of logical turn deadlines; overdue turns advance on the next read or action.
- Link, dash, surge and charge create positional, tempo and energy decisions. Evaluate multiple fixed policies; do not claim an exhaustive proof that no strategy dominates.
- Server rejects illegal moves, out-of-turn moves, stale writes and concurrent lost updates. Browser errors remain visible.
- Public game URL and public source repository are mandatory before the submission is complete.
- Verify engine, request handler, replay and SQL persistence. Build the complete app after the final source change.
- Browser QA is unavailable in this managed environment without the required browser skill; report that limit.
- No wallet operations, accounts, publication credentials, paid services or changes to Lira Ventures/SourceEnv are authorized by this implementation.

Delivery is not submitted or paid until separately evidenced on Taskmarket.
