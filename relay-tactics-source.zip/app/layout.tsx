import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Relay Tactics — Make the connection",
  description: "A quick multiplayer strategy game for humans and agents. Build a network, contest the beacons, and outscore your rivals.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
