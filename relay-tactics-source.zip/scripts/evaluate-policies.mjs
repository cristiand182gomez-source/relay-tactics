import { createGame, joinGame, startGame, playMove, chooseBotMove } from '../lib/game.mjs';
const styles = ['balanced', 'edge', 'center', 'surge'];
const matches = [], totals = Object.fromEntries(styles.map(s => [s, { wins: 0, shared: 0, losses: 0, score: 0 }]));
for (const a of styles) for (const b of styles) {
  if (a === b) continue;
  let g = createGame('EVAL23', 2, a, 0); g = joinGame(g, b, 0).game; g = startGame(g, 0, false, 0);
  while (g.status === 'playing') g = playMove(g, g.turn, chooseBotMove(g, [a, b][g.turn]), g.history.length + 1, 'evaluation');
  matches.push({ seats: [a, b], scores: g.players.map(p => p.score), winners: g.winners.map(i => [a, b][i]) });
  for (const p of g.players) { const t = totals[[a, b][p.id]]; t.score += p.score; if (!g.winners.includes(p.id)) t.losses++; else if (g.winners.length > 1) t.shared++; else t.wins++; }
}
console.log(JSON.stringify({ scope: '12 deterministic two-player policy matchups with both seat orders. This is a finite heuristic comparison, not proof of balanced human play or no dominant strategy.', matches, totals }, null, 2));
