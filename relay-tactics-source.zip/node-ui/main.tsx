import { createRoot } from 'react-dom/client';
import Home from '../app/page';
import '../app/globals.css';

createRoot(document.getElementById('root')!).render(<>
  <Home />
  <p style={{ maxWidth: 1224, margin: '0 auto 24px', padding: '0 18px', color: '#a5b1ae', fontSize: 12 }}>
    Demo hosting: rooms can be lost when the server restarts. Save replay JSON after your match.
  </p>
</>);
