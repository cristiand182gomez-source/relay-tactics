import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFile } from 'node:fs/promises';
import { D1Repository, MemoryRepository, handleRequest } from '../lib/service.mjs';
import { replay, snapshot } from '../lib/game.mjs';
import { botStep } from '../scripts/sample-bot.mjs';

const origin = 'https://relay.test';
function request(path, data, options = {}) { return new Request(`${origin}${path}`, { method: data === undefined ? 'GET' : 'POST', ...(data === undefined ? {} : { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }), ...options }); }
async function call(repo, path, data, now = 0, options = {}) { const response = await handleRequest(request(path, data, options), repo, now); return { status: response.status, body: await response.json() }; }
async function setup(repo = new MemoryRepository(), capacity = 2, humans = true) {
  let r = await call(repo, '/api/rooms', { capacity, name: 'Host' });
  assert.equal(r.status, 201); const code = r.body.game.code;
  if (humans) for (let i = 1; i < capacity; i++) { r = await call(repo, `/api/rooms/${code}/join`, { name: `Guest ${i}` }); assert.equal(r.status, 200); }
  r = await call(repo, `/api/rooms/${code}/start`, { player: 0, expectedVersion: r.body.game.version, fillBots: !humans });
  assert.equal(r.status, 200);
  return { repo, code, game: r.body.game };
}

test('full request flow creates, joins, starts, plays and exposes verified replay', async () => {
  const { repo, code, game } = await setup();
  assert.match(code, /^[A-Z2-9]{6}$/);
  let r = await call(repo, `/api/rooms/${code}/moves`, { player: 0, expectedVersion: game.version, move: { kind: 'link', tile: 1 } }, 1);
  assert.equal(r.status, 200); assert.equal(r.body.game.board[1], 0);
  r = await call(repo, `/api/rooms/${code.toLowerCase()}`);
  assert.equal(r.status, 200);
  r = await call(repo, `/api/rooms/${code}/replay`, undefined, 480000);
  assert.equal(r.status, 200); assert.equal(r.body.game.status, 'finished');
  assert.deepEqual(snapshot(replay(r.body.initial, r.body.events, r.body.game)), snapshot(r.body.game));
});

test('validation rejects malformed bodies, excessive input, cross-origin writes and absent rooms', async () => {
  const repo = new MemoryRepository();
  assert.equal((await call(repo, '/api/health')).status, 200);
  assert.equal((await call(repo, '/api/rooms')).status, 405);
  assert.equal((await call(repo, '/api/rooms/ABC234')).status, 404);
  assert.equal((await call(repo, '/api/rooms/!!')).status, 400);
  assert.equal((await call(repo, '/api/rooms', { capacity: 5 })).status, 400);
  assert.equal((await call(repo, '/api/rooms', {}, 0, { headers: { 'Content-Type': 'text/plain' } })).status, 415);
  assert.equal((await call(repo, '/api/rooms', {}, 0, { body: '{broken' })).status, 400);
  assert.equal((await call(repo, '/api/rooms', [], 0)).status, 400);
  assert.equal((await call(repo, '/api/rooms', { name: 'x'.repeat(5000) })).status, 413);
  assert.equal((await call(repo, '/api/rooms', {}, 0, { headers: { 'Content-Type': 'application/json', Origin: 'https://elsewhere.test' } })).status, 403);
});

test('stale and simultaneous actions cannot overwrite an accepted action', async () => {
  const { repo, code, game } = await setup();
  const data = { player: 0, expectedVersion: game.version, move: { kind: 'link', tile: 1 } };
  const pair = await Promise.all([call(repo, `/api/rooms/${code}/moves`, data, 1), call(repo, `/api/rooms/${code}/moves`, { ...data, move: { kind: 'link', tile: 5 } }, 1)]);
  assert.deepEqual(pair.map(r => r.status).sort(), [200, 409]);
  const saved = (await call(repo, `/api/rooms/${code}`)).body.game;
  assert.equal(saved.history.length, 1); assert.equal(saved.version, game.version + 1);
  assert.equal((await call(repo, `/api/rooms/${code}/moves`, data)).status, 409);
});

test('concurrent joins allocate one final seat only', async () => {
  const repo = new MemoryRepository();
  const created = await call(repo, '/api/rooms', { capacity: 2 }); const code = created.body.game.code;
  const pair = await Promise.all([call(repo, `/api/rooms/${code}/join`, { name: 'A' }), call(repo, `/api/rooms/${code}/join`, { name: 'B' })]);
  assert.deepEqual(pair.map(r => r.status).sort(), [200, 409]);
  assert.equal((await repo.get(code)).players.length, 2);
});

test('illegal action and storage failure are reported and cannot masquerade as success', async () => {
  const { repo, code, game } = await setup();
  const bad = await call(repo, `/api/rooms/${code}/moves`, { player: 0, expectedVersion: game.version, move: { kind: 'link', tile: 12 } });
  assert.equal(bad.status, 422); assert.equal((await repo.get(code)).version, game.version);
  const failed = await call({ ...repo, create() { throw new Error('private database detail'); } }, '/api/rooms', {});
  assert.equal(failed.status, 503); assert.ok(!failed.body.error.includes('private'));
});

test('rooms expire after 24 hours and overdue reads persist timeout actions', async () => {
  const { repo, code } = await setup();
  const r = await call(repo, `/api/rooms/${code}`, undefined, 20000);
  assert.equal(r.status, 200); assert.equal(r.body.game.history[0].cause, 'timeout');
  assert.equal((await repo.get(code)).history.length, 1);
  assert.equal((await call(repo, `/api/rooms/${code}`, undefined, 86400001)).status, 410);
});

test('sample HTTP bot consumes real handler responses and only takes its own turn', async () => {
  const { repo, code, game } = await setup();
  let writes = 0;
  const fetcher = async (url, init) => { if (init?.method === 'POST') writes++; return handleRequest(new Request(url, init), repo, 1); };
  const wait = await botStep(origin, code, 1, fetcher);
  assert.equal(wait.acted, false); assert.equal(writes, 0);
  const moved = await botStep(origin, code, 0, fetcher);
  assert.equal(moved.acted, true); assert.equal(writes, 1); assert.equal(moved.game.version, game.version + 1);
  const move2 = await botStep(origin, code, 1, fetcher);
  assert.equal(move2.acted, true); assert.equal(writes, 2);
});

test('sample bot handles 409 by returning to its read loop, without retrying a POST', async () => {
  const { repo, code } = await setup(); let writes = 0;
  const fetcher = async (url, init) => { if (init?.method === 'POST') { writes++; return new Response('{"error":"Room changed"}', { status: 409 }); } return handleRequest(new Request(url), repo, 1); };
  const r = await botStep(origin, code, 0, fetcher);
  assert.equal(r.stale, true); assert.equal(writes, 1);
});

test('generated SQLite migration and D1 repository persist state across instances with CAS', async () => {
  const db = new DatabaseSync(':memory:');
  db.exec(await readFile(new URL('../drizzle/0000_equal_bishop.sql', import.meta.url), 'utf8'));
  const adapter = { prepare(sql) { const stmt = db.prepare(sql); return { bind(...values) { return { async run() { return { meta: { changes: stmt.run(...values).changes } }; }, async first() { return stmt.get(...values) || null; } }; } }; } };
  try {
    const first = new D1Repository(adapter), second = new D1Repository(adapter);
    const { code, game } = await setup(first, 4, false);
    assert.equal((await second.get(code)).version, game.version);
    const data = { player: 0, expectedVersion: game.version, move: { kind: 'charge' } };
    const pair = await Promise.all([call(first, `/api/rooms/${code}/moves`, data, 1), call(second, `/api/rooms/${code}/moves`, data, 1)]);
    assert.deepEqual(pair.map(r => r.status).sort(), [200, 409]);
    const saved = await first.get(code);
    assert.equal(saved.history.length, 4); assert.equal(saved.turn, 0);
    assert.deepEqual(snapshot(replay(saved.initial, saved.history, saved)), snapshot(saved));
    assert.equal(await second.create(saved), false, 'duplicate room cannot replace existing game');
  } finally { db.close(); }
});
