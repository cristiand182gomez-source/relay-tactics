import { pathToFileURL } from 'node:url';
import { chooseBotMove } from '../lib/game.mjs';

/** One read and at most one action. No automatic replay of an uncertain POST. */
export async function botStep(base, code, player, fetcher = fetch) {
  const url = `${base.replace(/\/$/, '')}/api/rooms/${encodeURIComponent(code)}`;
  const state = await fetcher(url);
  const result = await state.json();
  if (!state.ok) throw new Error(result.error || `Read failed: ${state.status}`);
  const game = result.game;
  if (game.status !== 'playing' || game.turn !== player) return { game, acted: false };
  const move = chooseBotMove(game);
  const response = await fetcher(`${url}/moves`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ player, expectedVersion: game.version, move }) });
  const action = await response.json();
  if (response.status === 409) return { game, acted: false, stale: true };
  if (!response.ok) throw new Error(action.error || `Move failed: ${response.status}`);
  return { game: action.game, acted: true, move };
}

async function main() {
  const [base, rawCode, seatArg] = process.argv.slice(2);
  if (!base || !rawCode || !['http:', 'https:'].includes(new URL(base).protocol)) {
    throw new Error('Usage: node scripts/sample-bot.mjs https://YOUR-GAME ROOMCODE [existing-seat-number]');
  }
  const code = rawCode.toUpperCase();
  let player;
  if (seatArg !== undefined) {
    player = Number(seatArg);
    if (!Number.isInteger(player) || player < 0 || player > 3) throw new Error('Seat must be 0, 1, 2, or 3.');
  } else {
    const response = await fetch(`${base.replace(/\/$/, '')}/api/rooms/${encodeURIComponent(code)}/join`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'Sample / HTTP bot' }) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || `Join failed: ${response.status}`);
    player = result.player;
  }
  console.log(`Room ${code}, seat ${player}. The host starts the lobby.`);
  const limit = Date.now() + 15 * 60 * 1000;
  while (Date.now() < limit) {
    const result = await botStep(base, code, player);
    if (result.acted) console.log(`v${result.game.version}: ${JSON.stringify(result.move)}`);
    if (result.game.status === 'finished') {
      console.log(JSON.stringify({ scores: result.game.players.map(p => p.score), winners: result.game.winners }));
      return;
    }
    await new Promise(resolve => setTimeout(resolve, 800));
  }
  throw new Error('Stopped after 15 minutes. No move was retried blindly.');
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) main().catch(e => { console.error(e.message); process.exitCode = 1; });
