// Short build verification harness, not an interactive preview server.
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { fileURLToPath } from 'node:url';
import { openRepository } from '../server/sqlite.mjs';
import { createGameServer } from '../server/http.mjs';

const storage = openRepository(':memory:');
const server = createGameServer({ repository: storage.repository, clientDir: fileURLToPath(new URL('../node-dist/client', import.meta.url)) });
try {
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  const origin = `http://127.0.0.1:${server.address().port}`;
  const page = await fetch(origin);
  assert.equal(page.status, 200);
  const html = await page.text();
  assert.match(html, /Relay Tactics/);
  const paths = [...html.matchAll(/(?:src|href)="(\/assets\/[^" ]+)"/g)].map(match => match[1]);
  assert.ok(paths.some(path => path.endsWith('.js')));
  assert.ok(paths.some(path => path.endsWith('.css')));
  for (const path of paths) {
    const asset = await fetch(`${origin}${path}`);
    assert.equal(asset.status, 200); assert.ok((await asset.arrayBuffer()).byteLength > 100);
  }
  const health = await fetch(`${origin}/api/health`);
  assert.equal(health.status, 200); assert.equal((await health.json()).ok, true);
  console.log(JSON.stringify({ ok: true, checks: ['built HTML', 'built JS and CSS over HTTP', 'API health'], assets: paths, scope: 'loopback HTTP; no live Render or browser test' }, null, 2));
} finally {
  await new Promise(resolve => { server.close(resolve); server.closeAllConnections(); });
  storage.close();
}
