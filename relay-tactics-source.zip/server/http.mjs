import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { handleRequest } from '../lib/service.mjs';

const mime = { '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.html': 'text/html; charset=utf-8' };
const errorBody = (status, message) => new Response(JSON.stringify({ error: message }), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });

export function createGameServer({ repository, clientDir, publicOrigin, now = Date.now }) {
  if (publicOrigin) {
    const url = new URL(publicOrigin);
    if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.pathname !== '/' || url.search || url.hash) throw new Error('PUBLIC_ORIGIN must be an HTTP(S) origin.');
    publicOrigin = url.origin;
  }
  return createServer({ requestTimeout: 15000, headersTimeout: 10000, maxHeaderSize: 8192 }, async (incoming, outgoing) => {
    let response;
    try {
      const base = publicOrigin || `http://${incoming.headers.host || 'localhost'}`;
      const url = new URL(incoming.url, base);
      if (url.origin !== new URL(base).origin) response = errorBody(400, 'Invalid request target.');
      else if (url.pathname === '/api' || url.pathname.startsWith('/api/')) {
        // Buffer at most 4 KiB. Keep the connection writable when rejecting a large body.
        let payload = null;
        if (incoming.method !== 'GET' && incoming.method !== 'HEAD') {
          const chunks = []; let length = 0;
          for await (const chunk of incoming.iterator({ destroyOnReturn: false })) {
            length += chunk.length;
            if (length > 4096) { response = errorBody(413, 'Request body is too large.'); incoming.resume(); break; }
            chunks.push(chunk);
          }
          payload = Buffer.concat(chunks);
        }
        if (!response) response = await handleRequest(new Request(url, {
          method: incoming.method, headers: incoming.headers,
          ...(payload === null ? {} : { body: payload }),
        }), repository, now());
      } else if (!['GET', 'HEAD'].includes(incoming.method)) response = errorBody(405, 'Use GET or HEAD.');
      else {
        const path = decodeURIComponent(url.pathname);
        const relative = path === '/' ? 'index.html' : path === '/favicon.svg' ? 'favicon.svg' : /^\/assets\/[A-Za-z0-9_-]+\.(?:js|css|svg)$/.test(path) ? path.slice(1) : null;
        if (!relative) response = errorBody(404, 'File not found.');
        else {
          try {
            const bytes = await readFile(resolve(clientDir, relative));
            const extension = relative.slice(relative.lastIndexOf('.'));
            response = new Response(bytes, { headers: {
              'Content-Type': mime[extension] || 'application/octet-stream',
              'Cache-Control': relative.startsWith('assets/') ? 'public, max-age=31536000, immutable' : 'no-cache',
              'X-Content-Type-Options': 'nosniff',
              'Referrer-Policy': 'same-origin',
            } });
          } catch (error) { if (error.code === 'ENOENT') response = errorBody(404, 'File not found.'); else throw error; }
        }
      }
    } catch { response = errorBody(503, 'Room service unavailable. Please try again.'); }
    outgoing.writeHead(response.status, Object.fromEntries(response.headers));
    outgoing.end(incoming.method === 'HEAD' ? undefined : Buffer.from(await response.arrayBuffer()));
  });
}
