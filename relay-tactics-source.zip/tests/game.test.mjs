import test from 'node:test';
import assert from 'node:assert/strict';
import { HOMES, BEACONS, createGame, joinGame, startGame, connected, legalMoves, playMove, chooseBotMove, catchUp, replay, snapshot } from '../lib/game.mjs';

function playing(capacity = 2, bots = false) {
  let g = createGame('ABC234', capacity, 'North', 0);
  if (!bots) while (g.players.length < capacity) g = joinGame(g, `Player ${g.players.length + 1}`, 0).game;
  return startGame(g, 0, bots, 0);
}

test('lobby requires 2–4 seats, enforces capacity, host and callsigns', () => {
  assert.throws(() => createGame('ABC234', 1, 'Host'), /2, 3, or 4/);
  assert.throws(() => createGame('ABC234', 2, {}), /text/);
  const lobby = createGame('ABC234', 2, '  North\n ', 0);
  assert.equal(lobby.players[0].name, 'North');
  assert.throws(() => startGame(lobby, 1), /host/);
  assert.throws(() => startGame(lobby, 0, false), /Wait for players/);
  const joined = joinGame(lobby, 'B'.repeat(50), 0);
  assert.equal(joined.player, 1); assert.equal(joined.game.players[1].name.length, 20);
  assert.equal(lobby.players.length, 1, 'inputs stay immutable');
  assert.throws(() => joinGame(joined.game, 'Extra'), /full/);
  assert.throws(() => joinGame(startGame(joined.game, 0), 'Late'), /already started/);
});

test('start fills only empty seats and initializes homes and first-turn energy', () => {
  const g = playing(4, true);
  assert.deepEqual(g.players.map(p => p.kind), ['human', 'bot', 'bot', 'bot']);
  assert.deepEqual(HOMES.map(t => g.board[t]), [0, 1, 2, 3]);
  assert.equal(g.players[0].energy, 4); assert.equal(g.deadline, 15000);
  assert.deepEqual(snapshot(g), g.initial);
});

test('illegal, disconnected, out-of-turn and home attacks leave the input intact', () => {
  const g = playing(); const before = structuredClone(g);
  assert.throws(() => playMove(g, 1, { kind: 'charge' }), /turn/);
  assert.throws(() => playMove(g, 0, { kind: 'link', tile: 12 }), /not legal/);
  assert.throws(() => playMove(g, 0, { kind: 'dash', path: [1, 9] }), /not legal/);
  g.board[1] = 1; g.board[5] = 1;
  assert.ok(!legalMoves(g).some(m => m.kind === 'surge' && m.tile === 24));
  g.board = before.board;
  assert.deepEqual(g, before);
});

test('server calculates link and dash costs even when the client lies', () => {
  let g = playing();
  g = playMove(g, 0, { kind: 'dash', path: [1, 2], cost: -100 }, 1);
  assert.equal(g.players[0].energy, 0);
  assert.equal(g.board[1], 0); assert.equal(g.board[2], 0);
  assert.equal(g.history[0].move.cost, 4);
  g = playMove(g, 1, { kind: 'charge' }, 2);
  assert.equal(g.players[0].energy, 1);
  assert.ok(!legalMoves(g).some(m => m.kind === 'dash'));
});

test('connected beacons score only at round end and rotate their bonus', () => {
  let g = playing(); g.board[1] = 0; g.board[2] = 0;
  g.board[23] = 1; g.board[22] = 1;
  g = playMove(g, 0, { kind: 'charge' }, 1);
  assert.deepEqual(g.players.map(p => p.score), [0, 0]);
  g = playMove(g, 1, { kind: 'charge' }, 2);
  assert.deepEqual(g.players.map(p => p.score), [3, 1]);
  assert.deepEqual(g.history[1].gains, [3, 1]);
  g = playMove(g, 0, { kind: 'charge' }, 3);
  g = playMove(g, 1, { kind: 'charge' }, 4);
  assert.deepEqual(g.players.map(p => p.score), [4, 2]);
});

test('a surge disconnects a branch before scoring; home cells stay protected', () => {
  let g = playing();
  [1, 2].forEach(t => { g.board[t] = 0; });
  [19, 14, 9, 8, 7, 6].forEach(t => { g.board[t] = 1; });
  g.turn = 1; g.players[1].energy = 6;
  assert.ok(connected(g, 0).has(2));
  g = playMove(g, 1, { kind: 'surge', tile: 1 }, 1);
  assert.equal(g.board[1], -1); assert.equal(g.board[2], 0);
  assert.equal(connected(g, 0).has(2), false);
  assert.equal(g.players[0].score, 0);
  g.turn = 1; g.board[5] = 1; g.players[1].energy = 6;
  assert.ok(!legalMoves(g).some(m => m.kind === 'surge' && m.tile === 0));
});

test('ties have an explicit shared final outcome and cannot accept more moves', () => {
  let g = playing();
  while (g.status === 'playing') g = playMove(g, g.turn, { kind: 'charge' }, 1);
  assert.deepEqual(g.winners, [0, 1]); assert.equal(g.history.length, 24);
  assert.throws(() => playMove(g, 0, { kind: 'charge' }), /not playing/);
});

for (const capacity of [2, 3, 4]) {
  test(`${capacity}-player abandoned match resolves by 480 seconds of logical deadlines`, () => {
    const g = catchUp(playing(capacity), 480000);
    assert.equal(g.status, 'finished');
    assert.equal(g.history.length, capacity * g.rounds);
    assert.equal(g.history.at(-1).at, 480000);
    assert.ok(g.history.every(e => e.cause === 'timeout'));
    assert.deepEqual(snapshot(replay(g.initial, g.history, g)), snapshot(g));
  });
  test(`${capacity}-player mixed human/bot match uses legal moves, finite scores and reproducible replay`, () => {
    let g = playing(capacity, true), guard = 0;
    while (g.status === 'playing') {
      g = playMove(g, g.turn, chooseBotMove(g), ++guard);
      g = catchUp(g, guard);
      for (const p of g.players) { assert.ok(p.energy >= 0 && p.energy <= 6); assert.ok(Number.isInteger(p.score) && p.score >= 0); assert.equal(g.board[HOMES[p.id]], p.id); }
      assert.ok(guard <= capacity * g.rounds);
    }
    assert.ok(g.winners.length > 0);
    assert.deepEqual(snapshot(replay(g.initial, g.history, g)), snapshot(g));
    const altered = structuredClone(g.history); altered[0].state.players[0].score++;
    assert.throws(() => replay(g.initial, altered, g), /Replay differs/);
  });
}

test('bot turns advance immediately; an unexpired human turn waits', () => {
  const before = playing(4, true);
  assert.equal(catchUp(before, 1), before);
  let g = playMove(before, 0, { kind: 'charge' }, 1);
  g = catchUp(g, 1);
  assert.equal(g.turn, 0); assert.equal(g.history.length, 4);
  assert.deepEqual(g.history.map(e => e.cause), ['human', 'bot', 'bot', 'bot']);
});
