import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core';
export const rooms = sqliteTable('rooms', {
  code: text('code').primaryKey(),
  version: integer('version').notNull(),
  payload: text('payload').notNull(),
  updatedAt: integer('updated_at').notNull(),
});
