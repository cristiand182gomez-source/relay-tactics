import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { D1Repository } from '../lib/service.mjs';

/** Single-process SQLite adapter; migrations run once at startup, before listening. */
export function openRepository(filename) {
  if (filename !== ':memory:') mkdirSync(dirname(filename), { recursive: true });
  const db = new DatabaseSync(filename);
  try {
    db.exec('PRAGMA busy_timeout = 5000; PRAGMA journal_mode = WAL;');
    const version = db.prepare('PRAGMA user_version').get().user_version;
    if (version > 1) throw new Error('Database schema is newer than this server.');
    if (version === 0) {
      db.exec('BEGIN IMMEDIATE');
      try {
        db.exec(readFileSync(new URL('../drizzle/0000_equal_bishop.sql', import.meta.url), 'utf8'));
        db.exec('PRAGMA user_version = 1; COMMIT');
      } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    const adapter = {
      prepare(sql) {
        const statement = db.prepare(sql);
        return { bind(...values) {
          return {
            async run() { return { meta: { changes: Number(statement.run(...values).changes) } }; },
            async first() { return statement.get(...values) ?? null; },
          };
        } };
      },
    };
    return { repository: new D1Repository(adapter), close: () => db.close() };
  } catch (error) { db.close(); throw error; }
}
