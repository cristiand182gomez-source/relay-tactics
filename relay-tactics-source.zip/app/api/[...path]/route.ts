import { env } from 'cloudflare:workers';
import { handleRequest, D1Repository } from '../../../lib/service.mjs';

export const dynamic = 'force-dynamic';
export async function GET(request: Request) {
  return handleRequest(request, new D1Repository(env.DB));
}
export async function POST(request: Request) {
  return handleRequest(request, new D1Repository(env.DB));
}
