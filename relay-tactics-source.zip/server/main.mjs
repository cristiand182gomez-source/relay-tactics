import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { openRepository } from './sqlite.mjs';
import { createGameServer } from './http.mjs';

const port = Number(process.env.PORT || 10000);
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT must be 1–65535.');
const storage = openRepository(resolve(process.env.SQLITE_PATH || './data/rooms.sqlite'));
const server = createGameServer({
  repository: storage.repository,
  clientDir: fileURLToPath(new URL('../node-dist/client', import.meta.url)),
  publicOrigin: process.env.PUBLIC_ORIGIN || process.env.RENDER_EXTERNAL_URL,
});
server.listen(port, '0.0.0.0', () => console.log(`Relay Tactics listening on port ${port}. SQLite is local to this instance.`));
for (const signal of ['SIGTERM', 'SIGINT']) process.once(signal, () => {
  server.close(() => { storage.close(); process.exit(0); });
  server.closeIdleConnections();
});
