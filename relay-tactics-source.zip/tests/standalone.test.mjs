import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { once } from 'node:events';
import { openRepository } from '../server/sqlite.mjs';
import { createGameServer } from '../server/http.mjs';
import { botStep, waitForReady } from '../scripts/sample-bot.mjs';
import { replay, snapshot } from '../lib/game.mjs';

async function fixture(t, options = {}) {
  const directory = await mkdtemp(join(tmpdir(), 'relay-http-'));
  const clientDir = join(directory, 'client');
  await mkdir(join(clientDir, 'assets'), { recursive: true });
  await writeFile(join(clientDir, 'index.html'), '<!doctype html><title>Relay Tactics</title>');
  await writeFile(join(clientDir, 'assets', 'main-ab12.js'), 'console.log("Relay")');
  const filename = join(directory, 'rooms.sqlite');
  const storage = openRepository(filename);
  const server = createGameServer({ repository: storage.repository, clientDir, ...options });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  const origin = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => {
    await new Promise(resolve => { server.close(resolve); server.closeAllConnections(); });
    storage.close(); await rm(directory, { recursive: true, force: true });
  });
  return { origin, filename, storage };
}
async function post(origin, path, body, headers = {}) {
  return fetch(`${origin}${path}`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body) });
}

for (const capacity of [2, 3, 4]) test(`actual HTTP clients and sample bot complete ${capacity}-seat match and verify every replay state`, async t => {
  const { origin, filename } = await fixture(t);
  let response = await post(origin, '/api/rooms', { capacity, name: 'HTTP host' });
  assert.equal(response.status, 201); let { game } = await response.json();
  const code = game.code;
  for (let seat = 1; seat < capacity; seat++) {
    response = await post(origin, `/api/rooms/${code}/join`, { name: `HTTP seat ${seat}` });
    assert.equal(response.status, 200); ({ game } = await response.json());
  }
  response = await post(origin, `/api/rooms/${code}/start`, { player: 0, expectedVersion: game.version, fillBots: false });
  assert.equal(response.status, 200); ({ game } = await response.json());
  let actions = 0;
  while (game.status === 'playing') {
    const result = await botStep(origin, code, game.turn);
    assert.equal(result.acted, true); game = result.game;
    assert.ok(++actions <= 32);
  }
  assert.equal(actions, capacity * (capacity === 2 ? 12 : 8));
  response = await fetch(`${origin}/api/rooms/${code}/replay`);
  assert.equal(response.status, 200);
  const recorded = await response.json();
  assert.equal(recorded.events.length, actions);
  assert.deepEqual(snapshot(replay(recorded.initial, recorded.events, recorded.game)), snapshot(game));
  // A new repository connection uses the saved database, not the first object's memory.
  const reopened = openRepository(filename);
  try { assert.deepEqual(snapshot(await reopened.repository.get(code)), snapshot(game)); }
  finally { reopened.close(); }
});

test('HTTP adapter serves only public assets and enforces JSON, body limit and write races', async t => {
  const { origin } = await fixture(t);
  let response = await fetch(origin);
  assert.equal(response.status, 200); assert.match(await response.text(), /Relay Tactics/);
  response = await fetch(`${origin}/assets/main-ab12.js`);
  assert.equal(response.status, 200); assert.match(response.headers.get('Content-Type'), /javascript/);
  for (const path of ['/server/main.mjs', '/.env', '/assets/%2e%2e%2frooms.sqlite']) assert.equal((await fetch(`${origin}${path}`)).status, 404);
  response = await post(origin, '/api/rooms', { name: 'x'.repeat(5000) });
  assert.equal(response.status, 413); assert.match((await response.json()).error, /large/);
  assert.equal((await post(origin, '/api/rooms', {}, { Origin: 'https://unrelated.test' })).status, 403);
  response = await post(origin, '/api/rooms', {}, { Origin: origin });
  assert.equal(response.status, 201); let { game } = await response.json();
  response = await post(origin, `/api/rooms/${game.code}/start`, { player: 0, expectedVersion: game.version });
  assert.equal(response.status, 200); ({ game } = await response.json());
  const move = { player: 0, expectedVersion: game.version, move: game.legalMoves[0] };
  const results = await Promise.all([post(origin, `/api/rooms/${game.code}/moves`, move), post(origin, `/api/rooms/${game.code}/moves`, move)]);
  assert.deepEqual(results.map(r => r.status).sort(), [200, 409]);
  for (const result of results) await result.arrayBuffer();
});

test('TLS reverse proxy uses configured public origin without trusting forwarded headers', async t => {
  const { origin } = await fixture(t, { publicOrigin: 'https://relay.example' });
  const response = await post(origin, '/api/rooms', {}, { Origin: 'https://relay.example' });
  assert.equal(response.status, 201); await response.arrayBuffer();
  const rejected = await post(origin, '/api/rooms', {}, { Origin: 'https://attacker.example', 'X-Forwarded-Host': 'attacker.example', 'X-Forwarded-Proto': 'https' });
  assert.equal(rejected.status, 403); await rejected.arrayBuffer();
});

test('bot waits for a cold host with GETs and stops immediately on API access denial', async () => {
  const methods = [];
  await waitForReady('https://relay.test', { intervalMs: 1, fetcher: async (url, options) => {
    methods.push(options.method || 'GET');
    return methods.length === 1 ? new Response('Starting', { status: 503 }) : Response.json({ ok: true });
  } });
  assert.deepEqual(methods, ['GET', 'GET']);
  let reads = 0;
  await assert.rejects(waitForReady('https://relay.test', { intervalMs: 1, fetcher: async () => { reads++; return new Response('Blocked', { status: 403 }); } }), /access denied/);
  assert.equal(reads, 1);
});
